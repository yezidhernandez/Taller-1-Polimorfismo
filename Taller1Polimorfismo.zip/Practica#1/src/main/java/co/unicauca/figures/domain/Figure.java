package co.unicauca.figures.domain;

/**
 *
 * @author brada
 */
public interface Figure {
    public double calculatePerimeter();
    public double calculateArea();
}
