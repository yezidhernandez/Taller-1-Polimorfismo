package co.unicauca.figures.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias para la clase Circle
 * Se validan múltiples valores de radio para verificar el cálculo
 * correcto de área y perímetro.
 * @author Yezid y Dayana
 */
public class testCircle {

    public testCircle() {
    }

    @Test
    public void testPerimeterMultipleRadios() {
        System.out.println("Testing calculatePerimeter con varios radios");

        Circle c1 = new Circle(1);
        assertEquals(Math.PI * 2, c1.calculatePerimeter(), 0.01);

        Circle c2 = new Circle(2.3);
        assertEquals(Math.PI * 2.3 * 2, c2.calculatePerimeter(), 0.01);

        Circle c3 = new Circle(0);
        assertEquals(0, c3.calculatePerimeter(), 0.01);
    }

    @Test
    public void testAreaMultipleRadios() {
        System.out.println("Testing calculateArea con varios radios");

        Circle c1 = new Circle(1);
        assertEquals(Math.PI * 1 * 1, c1.calculateArea(), 0.01);

        Circle c2 = new Circle(2.3);
        assertEquals(Math.PI * 2.3 * 2.3, c2.calculateArea(), 0.01);

        Circle c3 = new Circle(0);
        assertEquals(0, c3.calculateArea(), 0.01);
    }

    @Test
    public void testCambiarRadio() {
        System.out.println("Testing setRadio y getRadio");

        Circle c = new Circle(5);
        assertEquals(5, c.getRadio(), 0.01);

        c.setRadio(3.5);
        assertEquals(3.5, c.getRadio(), 0.01);
        assertEquals(Math.PI * 3.5 * 3.5, c.calculateArea(), 0.01);
    }
}
